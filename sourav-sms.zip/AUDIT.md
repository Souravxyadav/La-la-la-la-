# AUDIT REPORT — 28 Oct 2026 (v3.1)
Method: backend run against a mocked Google environment (40 checks), static scan (ids, files, nav, CSS), real Chromium browser E2E on desktop + 375px mobile (26 checks) using the real Code.gs. NOT tested on a real Google account.

## Fixed
- No login rate limit -> lockout after 5 wrong tries (10 min).
- Logout did not end the server session -> new logout action.
- Default password could be deployed -> setup() refuses it.
- CSV/XLSX import could overwrite existing IDs or status -> id/status ignored on import.
- Formula injection (=, +, -, @) in Sheets and in CSV export -> neutralised.
- Unescaped status names in dropdowns -> escaped.
- Cryptic errors when server link missing/unreachable -> clear messages.
- Auto-refresh wiped typed filters -> paused while a filter/search is active.
- Inline script on login page (blocked strict CSP) -> moved to js/login.js; CSP + security headers added in .htaccess.
- Accessibility/meta: lang, theme-color, alert role on login error.

## Removed dead code
Earlier builds: placeholder variable on login, unused form parameter, old tag markup, old sidebar/nav code. Scan of js/ and gs/ found no unused functions or variables now (doPost/setup are Google entry points).

## Verified working (tests)
Login, wrong password, lockout, logout; student/scholarship add + validation (phone, marks, duplicate phone, name); eligibility incl. "Insufficient data"; apply, duplicate block, ineligible block; forward-only status, reject reason, final lock, per-scholarship flow; commission set per student (application can override); history; import; Tracker page + search; applications update; dashboard/reports/audit/settings render; no console errors; no horizontal overflow on 9 pages at 375px; mobile bottom nav.

## Also verified (second browser suite, tests/e2e2.py, 18 checks)
Edit, archive, student profile, CSV import (valid + invalid rows), bulk apply, bulk status, bulk reject with reason, award + commission (student + application override), final-status lock, tracker filter, inactive scholarship hidden, reports date filter, settings save, JSON backup, search, CSV export, sign out.

## Unverified (needs your real test)
Real Google deployment (permissions, Anyone access, speed); XLSX upload (needs internet for the SheetJS library, not testable offline); other browsers and real phones; large data (>2000 rows).

## Remaining issues / risks
- XLSX import uses SheetJS 0.18.5 from cdnjs (last cdnjs version, known old; no SRI hash set). Only import files you trust, or use CSV.
- Single admin password; token kept in browser localStorage (6h).
- Web app must be "Anyone" access; protection is the password + token.
- Not built: AI drafting, multiple admin roles, server-side pagination.
Student commission (type + value) is set in Add/Edit student; the dashboard has quick actions; global and scholarship commission were removed (v3.2).
