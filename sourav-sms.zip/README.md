# Sourav SMS (Google Apps Script + Google Sheets)
1. Google Sheet > Extensions > Apps Script. Paste gs/Code.gs. Change PASSWORD at the top (8+ characters; setup() refuses the default).
2. Run setup() once and authorize. Deploy > New deployment > Web app > Execute as: Me, Who has access: Anyone. Copy the /exec link.
3. Paste the link into js/config.js (or into the login page / Settings). Upload the folder to a static host (.htaccess adds security headers on Apache hosts).
4. Student import columns: name,phone,gender,dob,state,district,category,education,course,percentage,income,commission_type,commission_value (CSV or XLSX).
Docs: brain.md (state + rules), AUDIT.md (audit results). Tests: node tests/gs.test.js, python3 tests/static.py, python3 tests/e2e.py
