# BRAIN — Sourav SMS (read first, update after every change)
Updated: 2026-10-28 · Version: 3.2 (audited) · Owner testing: NOT yet tested on a real Google account. Verified with mocked-Google tests (tests/) + real-browser E2E. See AUDIT.md

## Stack
HTML5 + CSS3 + vanilla JS frontend (app.html single page, hash routes) · Google Apps Script `gs/Code.gs` backend · Google Sheets database. No other frameworks. SheetJS loaded on demand from cdnjs only for .xlsx import.
Connect: paste Web App `/exec` URL in `js/config.js`, or in the login page "Server link", or Settings → Server link (saved in browser).

## Business rules (do not break)
Admin only, no student login · admin applies for students · documents are a checklist only (no uploads) · eligibility + duplicate check on server, missing data = "Insufficient data" · status flows forward only, Rejected needs a reason, Disbursed/Rejected final · archive instead of delete · every change in Audit sheet · commission is set per student when adding/editing (percent of award or fixed ₹); one application can override it; NO global/scholarship default commission · IDs ST001/SC001/AP001 server-side · dates DD/MM/YYYY (IST).

## Data (Sheets, auto-created by setup())
Students, Scholarships (incl. `statuses` = optional own flow, blank = global), Applications, Audit. Settings (global status list, (removed: global commission), password hash) live in Script Properties.

## API actions (POST text/plain JSON {a,t,d})
login, list, save, importStudents, eligible, apply, apps, appUpdate, history, settings, saveSettings.

## Progress
DONE: login · dashboard (counts, pipeline bars, deadlines, activity) · students CRUD + profile + archive + CSV/XLSX import · scholarships CRUD + per-scholarship status flow · eligibility check + single/bulk apply · applications (status, award, commission override, checklist, notes, timeline) · reports by scholarship + CSV export · audit log · settings (status flow, (removed: global commission), password, server link) · 15s auto-refresh · reports with date range + pending commission · bulk status change on Applications · Student Tracker page (every student: scholarships applied + status + progress) · redesigned responsive UI (desktop sidebar, mobile bottom nav + card tables, auto dark mode) · sectioned Add Student / Add Scholarship forms with validation (client + server, duplicate phone blocked) · JSON backup · import skips invalid/duplicate rows.
NOT DONE: AI scholarship drafting · multiple admin roles · server-side pagination (fine under ~2000 rows).
NEXT: test live with real Sheet and fix anything found; then optional roles / AI drafting if wanted.

## Known notes
Re-run setup() after updating Code.gs (it fixes sheet headers) and redeploy as a NEW VERSION of the web app. Sheet columns are text-formatted so phone numbers keep leading zeros.


## Security & testing (v3.1)
Login lockout (5 wrong tries = 10 min), server logout, setup() refuses the default password, formula-injection neutralised in Sheets and CSV, import cannot overwrite IDs, CSP headers in .htaccess. Run: `node tests/gs.test.js` (backend), `python3 tests/static.py`, `python3 tests/e2e.py` (browser). Re-run all three after any change.
