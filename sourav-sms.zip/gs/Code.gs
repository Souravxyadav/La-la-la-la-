// Sourav SMS backend. 1) Paste into script.google.com bound to a Google Sheet 2) set PASSWORD 3) run setup() once 4) Deploy > Web app (Execute as: Me, Access: Anyone) 5) copy URL into js/config.js
const PASSWORD='change-me-123';
const PFX={Students:'ST',Scholarships:'SC',Applications:'AP'};
const COLS={
Students:['id','name','phone','gender','dob','state','district','category','education','course','percentage','income','status','commission_type','commission_value'],
Scholarships:['id','name','provider','amount','deadline','min_marks','max_income','states','categories','gender','education','documents','status','statuses'],
Applications:['id','student_id','scholarship_id','status','award','commission_type','commission_value','docs_done','notes','created','updated'],
Audit:['time','action','ref','detail']};
const P=PropertiesService.getScriptProperties();
const hash=s=>Utilities.base64Encode(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,s));
const now=()=>Utilities.formatDate(new Date(),'Asia/Kolkata','yyyy-MM-dd HH:mm:ss');
function setup(){if(PASSWORD==='change-me-123'||PASSWORD.length<8)throw new Error('Set a strong PASSWORD (8+ characters) at the top of Code.gs, then run setup() again');migrate();for(const n in COLS){const s=sh(n);s.getRange(1,1,1,COLS[n].length).setValues([COLS[n]]);}P.setProperty('pw',hash(PASSWORD));
 if(!P.getProperty('statuses'))P.setProperty('statuses','Applied,Submitted,Under Verification,Interview,Approved,Disbursed,Rejected');}
function migrate(){const s=sh('Scholarships');if(s.getLastRow()<1)return;const h=s.getRange(1,1,1,s.getLastColumn()).getValues()[0];
 ['commission_value','commission_type'].forEach(k=>{const i=h.indexOf(k);if(i>=0)s.deleteColumn(i+1);});}
function sh(n){const ss=SpreadsheetApp.getActive();let s=ss.getSheetByName(n);
 if(!s){s=ss.insertSheet(n);s.appendRow(COLS[n]);s.setFrozenRows(1);s.getRange(1,1,1000,COLS[n].length).setNumberFormat('@');}return s;}
function rows(n){const v=sh(n).getDataRange().getValues();const h=v.shift();
 return v.filter(r=>r[0]!=='').map(r=>{const o={};h.forEach((k,i)=>o[k]=r[i] instanceof Date?Utilities.formatDate(r[i],'Asia/Kolkata','yyyy-MM-dd'):String(r[i]));return o;});}
function log(a,ref,d){sh('Audit').appendRow([now(),a,ref,d||'']);}
function doPost(e){let q;try{q=JSON.parse(e.postData.contents);}catch(x){return out({err:'bad request'});}
 const L=LockService.getScriptLock();
 try{
  if(q.a==='login'){const C=CacheService.getScriptCache(),n=+(C.get('failcount')||0);if(n>=5)return out({err:'Too many attempts. Try again in 10 minutes'});
   if(hash(String((q.d||{}).password))!==P.getProperty('pw')){C.put('failcount',String(n+1),600);return out({err:'Wrong password'});}
   C.remove('failcount');const t=Utilities.getUuid();C.put('t'+t,'1',21600);log('login','admin');return out({data:t});}
  if(!q.t||!CacheService.getScriptCache().get('t'+q.t))return out({err:'auth'});
  if(q.a==='logout'){CacheService.getScriptCache().remove('t'+q.t);return out({data:1});}
  L.waitLock(20000);const f=API[q.a];if(!f)return out({err:'unknown action'});return out({data:f(q.d||{})});
 }catch(x){return out({err:String(x.message||x)});}finally{try{L.releaseLock();}catch(y){}}}
const cell=v=>{v=String(v);return /^[=+\-@]/.test(v)&&isNaN(v)?"'"+v:v;};
function val(n,r){if(r.status==='Archived')return;const bad=m=>{throw new Error(m)};
 if(r.name!==undefined&&!String(r.name).trim())bad('Name is required');
 if(n==='Students'){if(r.phone&&!/^\d{10}$/.test(r.phone))bad('Phone must be 10 digits');
  if(r.percentage!==undefined&&r.percentage!==''&&!(+r.percentage>=0&&+r.percentage<=100))bad('Marks must be 0-100');
  if(r.income!==undefined&&r.income!==''&&!(+r.income>=0))bad('Invalid income');
  if(r.phone&&rows('Students').some(x=>x.phone===r.phone&&x.id!==r.id&&x.status!=='Archived'))bad('Phone already exists');}
 if(n==='Scholarships'&&r.amount!==undefined&&r.amount!==''&&!(+r.amount>=0))bad('Invalid amount');}
function valComm(n,r){if((n==='Students'||n==='Applications')&&r.commission_value!==undefined&&r.commission_value!==''){
 if(!(+r.commission_value>=0))throw new Error('Invalid commission');if(!['percent','fixed'].includes(r.commission_type))throw new Error('Choose commission type');
 if(r.commission_type==='percent'&&+r.commission_value>100)throw new Error('Percent commission cannot exceed 100');}}
function out(o){return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);}
function statuses(){return P.getProperty('statuses').split(',');}
const stl=sc=>sc&&sc.statuses?sc.statuses.split(',').map(x=>x.trim()).filter(Boolean):statuses();
function comm(a,st){let t='',v=0;if(st&&st.commission_value!==''&&st.commission_value!==undefined){t=st.commission_type;v=+st.commission_value;}
 if(a.commission_value!==''){t=a.commission_type;v=+a.commission_value;}
 return Math.round(t==='fixed'?v:(+a.award||0)*v/100);}
function eligible(st,sc){const r=[],has=v=>v!==''&&v!==undefined,list=v=>String(v).split(',').map(x=>x.trim().toLowerCase()).filter(Boolean);
 const chk=(need,val,label,fn)=>{if(!has(need))return;if(!has(val))r.push(label+': Insufficient data');else if(!fn())r.push(label+' not met');};
 chk(sc.min_marks,st.percentage,'Marks',()=>+st.percentage>=+sc.min_marks);
 chk(sc.max_income,st.income,'Income',()=>+st.income<=+sc.max_income);
 [['states','state'],['categories','category'],['gender','gender'],['education','education']].forEach(k=>
  chk(sc[k[0]],st[k[1]],k[1],()=>list(sc[k[0]]).includes(String(st[k[1]]).toLowerCase())));
 if(sc.deadline&&sc.deadline<now().slice(0,10))r.push('Deadline passed');
 if(sc.status!=='Active')r.push('Scholarship not active');
 return r;}
const API={
 list:d=>rows(d.s),
 save:d=>{val(d.s,d.r);valComm(d.s,d.r);const s=sh(d.s),r=d.r,c=COLS[d.s];const all=s.getDataRange().getValues();let i=-1;
  if(r.id)i=all.findIndex((x,j)=>j&&x[0]===r.id);
  if(i<0){s.getRange(s.getLastRow()+1,1,1,c.length).setNumberFormat('@');let m=0;all.slice(1).forEach(x=>m=Math.max(m,parseInt(String(x[0]).slice(2))||0));r.id=PFX[d.s]+String(m+1).padStart(3,'0');
   if(d.s==='Students'&&!r.status)r.status='Active';s.appendRow(c.map(k=>r[k]===undefined?'':cell(r[k])));log('create '+d.s,r.id);}
  else{s.getRange(i+1,1,1,c.length).setValues([c.map((k,j)=>r[k]===undefined?all[i][j]:cell(r[k]))]);log('update '+d.s,r.id);}
  return r.id;},
 importStudents:d=>{let ok=0,bad=0;d.rows.forEach(r=>{try{delete r.id;delete r.status;if(/^\d\d\/\d\d\/\d{4}$/.test(r.dob))r.dob=r.dob.split('/').reverse().join('-');API.save({s:'Students',r:r});ok++;}catch(e){bad++;}});return{ok:ok,bad:bad};},
 eligible:d=>{const sc=rows('Scholarships').find(x=>x.id===d.sid);const done=rows('Applications').filter(a=>a.scholarship_id===sc.id).map(a=>a.student_id);
  return rows('Students').filter(s=>s.status==='Active').map(s=>({s:s,why:eligible(s,sc),applied:done.includes(s.id)}));},
 apply:d=>{const st=rows('Students').find(x=>x.id===d.student_id),sc=rows('Scholarships').find(x=>x.id===d.scholarship_id);
  if(!st||!sc)throw new Error('Not found');const why=eligible(st,sc);if(why.length)throw new Error('Not eligible: '+why.join('; '));
  if(rows('Applications').some(a=>a.student_id===st.id&&a.scholarship_id===sc.id&&a.status!=='Archived'))throw new Error('Already applied');
  return API.save({s:'Applications',r:{student_id:st.id,scholarship_id:sc.id,status:stl(sc)[0],award:sc.amount,commission_type:'',commission_value:'',docs_done:'',notes:'',created:now(),updated:now()}});},
 apps:()=>{const S=rows('Scholarships'),T=rows('Students');return rows('Applications').map(a=>{const sc=S.find(x=>x.id===a.scholarship_id)||{},st=T.find(x=>x.id===a.student_id)||{};
  a.student=st.name;a.scholarship=sc.name;a.documents=sc.documents||'';a.commission=comm(a,st);a.flow=stl(sc).join(',');return a;});},
 appUpdate:d=>{const a=rows('Applications').find(x=>x.id===d.id),sc=rows('Scholarships').find(x=>x.id===a.scholarship_id),L=stl(sc),n=d.status;
  if(n&&!L.includes(n))throw new Error('Status not in this scholarship flow');
  if(n&&n!==a.status){if(['Disbursed','Rejected'].includes(a.status))throw new Error('Final status cannot change');
   if(n!=='Rejected'&&L.indexOf(n)<L.indexOf(a.status))throw new Error('Status can only move forward');
   if(n==='Rejected'&&!d.note)throw new Error('Reason required to reject');}
  const r={id:a.id,updated:now()};['status','docs_done','commission_type','commission_value','award'].forEach(k=>{if(d[k]!==undefined)r[k]=d[k];});
  if(d.note)r.notes=(a.notes?a.notes+'\n':'')+now().slice(0,10)+': '+d.note;
  API.save({s:'Applications',r:r});if(n&&n!==a.status)log('status',a.id,a.status+' -> '+n+(d.note?' ('+d.note+')':''));return 1;},
 history:d=>rows('Audit').filter(x=>x.ref===d.id),
 settings:()=>({statuses:statuses().join(',')}),
 saveSettings:d=>{if(d.statuses)P.setProperty('statuses',d.statuses);
  if(d.password){if(d.password.length<8)throw new Error('Min 8 characters');P.setProperty('pw',hash(d.password));}log('settings','admin');return 1;}
};
