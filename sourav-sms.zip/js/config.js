// Paste your Google Apps Script Web App URL here (ends with /exec)
const GS_URL="PASTE_YOUR_GS_WEB_APP_URL_HERE";
