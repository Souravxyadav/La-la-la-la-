const $=s=>document.querySelector(s);if(localStorage.t)location='app.html';
$('#g').value=localStorage.gs||'';
$('#f').onsubmit=async e=>{e.preventDefault();$('#e').textContent='';try{const g=$('#g').value.trim();if(g)localStorage.gs=g;const G=localStorage.gs||GS_URL;
 if(!/^https?:\/\/|^\//.test(G))throw Error('Paste your Google Script link in the Server link box');
 let j;try{j=await(await fetch(G,{method:'POST',body:JSON.stringify({a:'login',d:{password:$('#p').value}})})).json()}catch(x){throw Error('Cannot reach server. Check the link and internet.')}
 if(j.err)throw Error(j.err);localStorage.t=j.data;location='app.html'}catch(x){$('#e').textContent=x.message}};
