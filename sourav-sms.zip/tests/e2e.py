# Browser test: python3 tests/e2e.py  (needs playwright + chromium). Uses the real Code.gs via tests/e2e_server.js
import subprocess,time,sys,os
from playwright.sync_api import sync_playwright
D=os.path.dirname(os.path.abspath(__file__));srv=subprocess.Popen(['node',D+'/e2e_server.js']);time.sleep(1.2)
res=[];errs=[]
def chk(c,m):res.append((bool(c),m));print(('PASS ' if c else 'FAIL ')+m)
try:
 with sync_playwright() as p:
  b=p.chromium.launch();ctx=b.new_context(viewport={'width':1280,'height':800});ctx.add_init_script("localStorage.gs='/gs'");pg=ctx.new_page()
  pg.on('console',lambda m:errs.append(m.text) if m.type=='error' else None);pg.on('pageerror',lambda e:errs.append(str(e)))
  U='http://localhost:8765/';pg.goto(U+'index.html');pg.fill('#p','wrong');pg.click('button');pg.wait_for_selector('#e:not(:empty)');chk('Wrong' in pg.inner_text('#e'),'login rejects wrong password')
  pg.fill('#p','TestPass#2026');pg.click('button');pg.wait_for_url('**/app.html');pg.wait_for_selector('.grid');chk(True,'login works, dashboard loads')
  def go(h):pg.goto(U+'app.html#'+h);pg.reload();pg.wait_for_selector('#v .card, #v .bar',timeout=8000)
  go('students');pg.click('#add');pg.fill('[name=name]','Ravi Kumar');pg.fill('[name=phone]','123');pg.click('#ok');pg.wait_for_selector('#toast:visible');chk('10 digits' in pg.inner_text('#toast'),'student form validates phone')
  pg.fill('[name=phone]','9876500001');pg.fill('[name=state]','Bihar');pg.select_option('[name=category]','SC');pg.select_option('[name=education]','UG');pg.fill('[name=percentage]','80');pg.fill('[name=income]','100000');pg.select_option('[name=commission_type]','percent');pg.fill('[name=commission_value]','10');pg.click('#ok');pg.wait_for_selector('td:has-text("Ravi Kumar")');chk(True,'add student saves and lists')
  go('scholarships');pg.click('#add');pg.fill('[name=name]','Merit Award');pg.fill('[name=amount]','50000');pg.fill('[name=deadline]','2099-12-31');pg.fill('[name=min_marks]','60');pg.fill('[name=documents]','Aadhaar, Marksheet');pg.click('#ok');pg.wait_for_selector('td:has-text("Merit Award")');chk(True,'add scholarship saves and lists')
  go('eligibility');pg.select_option('#sc','SC001');pg.wait_for_selector('[data-s]');pg.click('[data-s]');pg.wait_for_selector('td:has-text("Already applied")',state='attached') if False else pg.wait_for_timeout(1200);chk(pg.locator('#toast').inner_text().startswith('Application created'),'eligible student applied')
  go('tracker');chk('Ravi Kumar' in pg.inner_text('#t') and 'Merit Award' in pg.inner_text('#t') and 'Applied' in pg.inner_text('#t'),'tracker shows student, scholarship, status')
  go('applications');pg.click('[data-i]');pg.select_option('#ns','Approved');pg.fill('#nt','ok');pg.click('#ok');pg.wait_for_timeout(1200);chk('Approved' in pg.inner_text('#t'),'application status update works');chk('5,000' in pg.inner_text('#t'),'commission from student record applied')
  pg.click('[data-i]');pg.wait_for_selector('#hs:not(:has-text("Loading"))');chk('Applied -> Approved' in pg.inner_text('#hs'),'timeline shows status change');pg.click('#x')
  for h in['dashboard','reports','audit','settings']:go(h);chk(len(pg.inner_text('#v'))>20,'page renders: '+h)
  go('tracker');pg.fill('#q','nomatch');chk('No students found' in pg.inner_text('#t'),'tracker search filters')
  mc=b.new_context(viewport={'width':375,'height':700});mc.add_init_script("localStorage.gs='/gs'");m=mc.new_page();m.on('pageerror',lambda e:errs.append(str(e)))
  m.goto(U+'index.html');m.fill('#p','TestPass#2026');m.click('button');m.wait_for_url('**/app.html')
  for h in['dashboard','students','scholarships','eligibility','applications','tracker','reports','audit','settings']:
   m.goto(U+'app.html#'+h);m.reload();m.wait_for_selector('#v .card, #v .bar',timeout=8000);ov=m.evaluate('document.documentElement.scrollWidth>innerWidth+1');chk(not ov,'mobile no horizontal overflow: '+h)
  chk(m.evaluate("getComputedStyle(document.querySelector('nav')).position")=='fixed' and m.evaluate("document.querySelector('nav').getBoundingClientRect().bottom")>=690,'mobile bottom nav visible')
  chk(not errs,'no console/page errors '+str(errs[:3]));b.close()
finally:srv.kill()
print('E2E:',sum(1 for r in res if r[0]),'passed,',sum(1 for r in res if not r[0]),'failed')
