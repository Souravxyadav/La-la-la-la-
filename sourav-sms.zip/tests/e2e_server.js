// Serves the site + runs the REAL Code.gs behind /gs (mocked Google services) for browser tests
const http=require('http'),fs=require('fs'),path=require('path'),vm=require('vm'),{ctx}=require('./mock');const root=path.join(__dirname,'..');
const mime={'.html':'text/html','.js':'text/javascript','.css':'text/css'};
http.createServer((q,r)=>{if(q.method==='POST'&&q.url==='/gs'){let b='';q.on('data',c=>b+=c);q.on('end',()=>{const o=vm.runInContext(`doPost({postData:{contents:${JSON.stringify(b)}}}).s`,ctx);r.setHeader('content-type','application/json');r.end(o)});return}
 const f=path.join(root,q.url.split('?')[0]==='/'?'index.html':q.url.split('?')[0]);if(!f.startsWith(root)||!fs.existsSync(f)||fs.statSync(f).isDirectory()){r.statusCode=404;return r.end('nf')}
 r.setHeader('content-type',mime[path.extname(f)]||'text/plain');r.end(fs.readFileSync(f))}).listen(8765);
