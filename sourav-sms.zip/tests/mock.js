// Runs gs/Code.gs against a mocked Google environment: node tests/gs.test.js
const fs=require('fs'),vm=require('vm'),cr=require('crypto');
let src=fs.readFileSync(__dirname+'/../gs/Code.gs','utf8').replace(/const PASSWORD='[^']*'/,"const PASSWORD='TestPass#2026'");
const sheets={},props={},cache={};
const mk=()=>{const data=[];return{data,appendRow:r=>data.push(r.slice()),setFrozenRows(){},getLastRow:()=>data.length,getLastColumn:()=>Math.max(0,...data.map(r=>r.length)),deleteColumn:i=>data.forEach(r=>r.splice(i-1,1)),
 getRange:(r,c,nr,nc)=>({setNumberFormat(){return this},getValues:()=>[data[r-1].slice(c-1,c-1+nc)],setValues(v){v.forEach((row,i)=>{data[r-1+i]=data[r-1+i]||[];row.forEach((x,j)=>data[r-1+i][c-1+j]=x)})}}),
 getDataRange:()=>({getValues:()=>data.map(r=>r.slice())})}};
const ctx=vm.createContext({console,Buffer,
 SpreadsheetApp:{getActive:()=>({getSheetByName:n=>sheets[n]||null,insertSheet:n=>sheets[n]=mk()})},
 PropertiesService:{getScriptProperties:()=>({getProperty:k=>props[k]??null,setProperty:(k,v)=>props[k]=v})},
 CacheService:{getScriptCache:()=>({put:(k,v)=>cache[k]=v,get:k=>cache[k]??null,remove:k=>delete cache[k]})},
 LockService:{getScriptLock:()=>({waitLock(){},releaseLock(){}})},
 Utilities:{DigestAlgorithm:{SHA_256:1},computeDigest:(a,s)=>[...cr.createHash('sha256').update(s).digest()],base64Encode:b=>Buffer.from(b).toString('base64'),getUuid:()=>cr.randomUUID(),
  formatDate:(d,tz,f)=>{const t=new Date(d.getTime()+19800000).toISOString();return f.includes('HH')?t.slice(0,10)+' '+t.slice(11,19):t.slice(0,10)}},
 ContentService:{MimeType:{JSON:1},createTextOutput:s=>({s,setMimeType(){return this}})}});
vm.runInContext(src,ctx);vm.runInContext('setup()',ctx);
module.exports={ctx,cache,sheets};
