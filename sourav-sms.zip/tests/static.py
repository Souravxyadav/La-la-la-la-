import re,os,sys
R=os.path.join(os.path.dirname(__file__),'..');rd=lambda p:open(os.path.join(R,p)).read()
html={f:rd(f) for f in os.listdir(R) if f.endswith('.html')};js={f:rd('js/'+f) for f in os.listdir(R+'/js')};css=rd('css/style.css')
allsrc=''.join(html.values())+''.join(js.values());bad=0
def rep(t,l):
    global bad
    if l: bad+=1;print('ISSUE',t,sorted(set(l)))
defd=set(re.findall(r'id="([\w-]+)"',allsrc));used=set(re.findall(r"\$\('#([\w-]+)'\)",allsrc))|set(re.findall(r"getElementById\('([\w-]+)'\)",allsrc))
rep('ids used in JS but never defined',used-defd)
for f,t in html.items():
    for m in re.findall(r'(?:src|href)="([^"#]+)"',t):
        if not m.startswith('http') and not os.path.exists(os.path.join(R,m)):rep('missing file in '+f,[m])
sel=set(re.findall(r'\.([a-zA-Z][\w-]*)',re.sub(r'\{[^}]*\}','{}',re.sub(r'/\*.*?\*/','',css))))
sel={c for c in sel if not re.fullmatch(r'\d+',c)}
used_c=set(re.findall(r'class="([^"]+)"',allsrc));uc=set(c for x in used_c for c in re.split(r'[\s$]',x));uc|=set(re.findall(r'class="(?:[^"$]*)\$\{[^}]*\}[^"]*"',allsrc) and [])
uc|=set(re.findall(r'"bd ([\w]+)"',allsrc))|set(re.findall(r"'(no|ok|wa|in)'",allsrc))
rep('CSS classes never used (check manually)',[c for c in sel if c not in uc and c not in allsrc.replace('.'+c,'')])
nav=re.findall(r"\['(\w+)','[^']+','[^']+'\]",re.search(r'const NAV=.*',js['app.js']).group(0));views=set(re.findall(r'^(?:async )?(\w+)\(\)\{',js['app.js'].split('const V={')[1].split('const NAV')[0],re.M))
rep('nav entries without a view',[n for n in nav if n not in views and n!='out'])
print('static checks done, issues:',bad)
